# 3d-basics
A set of small projects to learn &amp; master game development in Unity 3D
